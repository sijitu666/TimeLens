# TimeLens: Evidence-Grounded Temporal Reasoning（EG-CoT + EAR）实现记录

日期：2026-03-10

本文档用于**完整记录**本次在 `TencentARC/TimeLens` 仓库内完成的科研工程实现：
- EG-CoT（Evidence-Grounded Chain-of-Thought）SFT 数据构建与 Prompt 支持
- EAR（Evidence-Aware Reward）奖励函数 + GRPO 训练接入
- QueryComplexityEstimator（规则 + 可选 surprisal）
- ReasonVTG-Bench 候选数据构建脚本
- 评测脚本按 query_type 分组统计
- LoRA 场景训练结束自动合并权重再评测
- tmux 一键启动脚本（明早可直接跑）

> 说明：本文档面向“机器要关机、晚上回家复盘”的需求，尽量写到可直接复现。

---

## 0. 环境与约束

- 仓库路径：`/mnt/bn/aidp-data-multimodal-lf1/zhiwei/TimeLens`
- Conda：`/home/tiger/miniconda3`
- 主要 conda 环境：`timelens`
- tmux：`tmux 3.3a`

重要约束（按你的要求实现）：
- 不改模型结构（创新全部在 data/prompt/reward/training strategy）
- 单卡 A100-80GB 训练（脚本不要求多卡；如多卡靠 `CUDA_VISIBLE_DEVICES`）
- 优先 plug-in/参数开关，不破坏 TimeLens 旧流程

---

## 1. 交付能力总览（你明早能跑起来的东西）

### 1.1 EG-CoT 数据与 Prompt

- 训练数据输出支持两种格式：
  - 感知型：`<answer>start - end</answer>`
  - 推理型：
    ```
    <think>
    [Evidence@X.X-Y.Ys] ...
    [Reasoning] ...
    </think>
    <answer>start - end</answer>
    ```

- SFT/GRPO Prompt 可切换：
  - `--prompt_template legacy`（旧 TimeLens prompt）
  - `--prompt_template egcot`（新 EG-CoT prompt）

### 1.2 EAR 奖励函数（GRPO）

新增 reward：`ear`，公式：

`R = R_answer × (1 + α × R_evidence) × γ_efficiency + δ × 𝟙(Perception)`

- `R_answer`：tIoU(pred, gt)
- `R_evidence`：从 `[Evidence@...]` 提取的证据时间戳与 GT 的相关性（IoU + proximity）
- `γ_efficiency`：证据步数冗余惩罚（基于 ref_steps）
- `δ`：感知型 query 且不输出 `<think>` 的小 bonus

启用方式：GRPO 脚本传 `--reward_funcs ear`。

### 1.3 ReasonVTG-Bench 候选数据

基于 TimeLens-Bench（ActivityNet/Charades/QVHighlights）生成 reasoning-intense 候选 query（模板组合生成，默认 `needs_human_verification=true`）。

### 1.4 tmux 一键启动

新增一键脚本：`scripts/tmux_start_egcot_pipeline.sh`

会创建 4 个窗口分别执行：
- `egcot_data`：构建 EG-CoT SFT jsonl
- `reasonvtg`：构建 ReasonVTG 候选
- `sft_egcot`：SFT（egcot_jsonl + egcot prompt）
- `grpo_ear`：GRPO+Eval（EAR + egcot prompt）

---

## 2. 文件改动清单（按模块划分）

### 2.1 数据构建（CPU）

**新增** `scripts/build_egcot_data.py`
- 作用：从 TimeLens-100K 原始 jsonl（每行 video + events）展开并构建 EG-CoT SFT 训练 jsonl。
- 关键点：
  - 自动展开 `events[]` 为一条条样本（避免输入结构不匹配）。
  - 规则复杂度分类：优先复用 `training/train/query_complexity.py`。
  - 占比控制：通过“保留全部 reasoning + 下采样 perception”逼近 `--target_reasoning_ratio`。
  - `--llm_provider none|openai|gemini`：
    - `none`：启发式生成（先跑通 pipeline）
    - `openai/gemini`：外部 API（带 cache/retry/强制 `<answer>`=GT）

**新增** `scripts/build_reasonvtg_bench.py`
- 作用：基于 TimeLens-Bench json 生成 ReasonVTG 候选（pair/triplet 组合）。
- 输出：jsonl，每条带 `needs_human_verification=true`，并保留 `source_queries/source_spans` 便于人工审。

**新增** `scripts/prepare_egcot_data.sh`
- 作用：封装 `build_egcot_data.py` 的 CPU 一键命令。

**新增** `scripts/prepare_reasonvtg_candidates.sh`
- 作用：封装 `build_reasonvtg_bench.py` 的 CPU 一键命令（默认跑 3 个 bench json）。

---

### 2.2 训练侧（SFT/GRPO）Prompt 开关与数据接入

**修改** `training/params.py`
- DataArguments 新增：`prompt_template`（`legacy|egcot`）。

**修改** `training/data/grounding.py`
- 新增 `PROMPT_EGCOT`（EG-CoT prompt）。
- 新增 `_select_prompt_text()`：按 `data_args.prompt_template` 切 prompt。
- SFT：若 `prompt_template=egcot` 且样本包含 `anno['response']`，优先用该 response，否则退化为 `<answer>`。
- 新增数据集：`egcot_jsonl`（从 `data_args.data_path` 读取由 `build_egcot_data.py` 生成的 jsonl）。

**修改** `training/data/hybrid.py`
- datasets 列表新增：`egcot_jsonl`。

---

### 2.3 Reward（EAR）与复杂度估计

**新增** `training/train/query_complexity.py`
- `QueryComplexityEstimator(mode=rule_based|surprisal)`：
  - rule_based：训练默认使用
  - surprisal：可选（依赖 torch/transformers；缺依赖会给出明确报错）

**修改** `training/train/reward_funcs.py`
- `format_reward` 放宽：允许只有 `<answer>...</answer>`（感知型跳过推理）。
- 新增 `evidence_aware_reward` 并注册为 `ear`。
- 内部的 `classify_query_complexity_simple` 改为优先复用 `QueryComplexityEstimator`。

---

### 2.4 评测与指标

**修改** `evaluation/compute_metrics.py`
- 新增 `--group_by_query_type`：按 query_type 分组统计 IOU0.3/0.5/0.7 与 mIoU。
- query_type 分类优先复用 `QueryComplexityEstimator(rule_based)`。

**修改** `evaluation/eval_dataloader.py`
- 修复 model load：
  - transformers 正确参数为 `torch_dtype`，且 Qwen3 需要 `trust_remote_code=True`。
  - 若是 LoRA adapter（含 `adapter_config.json`），支持 base+adapter 加载。

---

### 2.5 LoRA 自动合并 + Eval

**新增/修改** `scripts/merge_lora.py`
- 从“写死路径的小脚本”改为通用 CLI：
  - `--lora_path / --out_path / --base_model_path`
  - `--skip_if_exists / --dry_run`

**修改** `train_scripts/run_grpo_qwen3_8b.sh`
- 若 `--model_path` 为 LoRA adapter，训练前自动 merge 到 `${model_path}_merged`。
- 自动推断 `num_devices`（从 `CUDA_VISIBLE_DEVICES` 或 `nvidia-smi -L`），并校验 batch 关系。
- 新增参数透传：`--prompt_template`、`--reward_funcs`。

**修改** `train_scripts/run_grpo_and_eval_qwen3_8b.sh`
- 训练前：若 base 为 adapter，先 merge。
- 训练后：若训练产物是 adapter，merge 到 `${trained_model_path}_merged`，eval 用 merged。
- 新增参数透传：`--prompt_template`、`--reward_funcs`。

**修改** `train_scripts/run_sft_qwen3_8b.sh`
- 新增参数透传：`--data_path`、`--prompt_template`，用于 `egcot_jsonl`。

---

### 2.6 tmux 一键启动与技能沉淀

**新增** `scripts/tmux_start_egcot_pipeline.sh`
- 一键 tmux 启动（4 个窗口），每个窗口都会 conda activate 并 cd repo。
- 必填参数：
  - `--base_model_path`（SFT base）
  - `--filtered_jsonl`（GRPO input）
- 可选：`--sft_ckpt_path`（有现成 SFT 则跳过 SFT window）

**新增** `evidence-grounded-tvg.SKILL.md`
- 本次工作复用指南：数据构建、开关、reward、评测分组、tmux、排错。

**修改** `param-line-edit-helper.SKILL.md`
- 增补 tmux 一键启动的 prompt 模板。

---

## 3. 运行方式（可直接复制）

### 3.1 CPU：数据准备

```bash
source /home/tiger/miniconda3/etc/profile.d/conda.sh
conda activate timelens
cd /mnt/bn/aidp-data-multimodal-lf1/zhiwei/TimeLens

bash scripts/prepare_egcot_data.sh \
  --input_jsonl data/TimeLens-100K/timelens-100k.jsonl \
  --output_jsonl output/TimeLens-8B/sft/egcot_timelens100k.jsonl \
  --target_reasoning_ratio 0.4

bash scripts/prepare_reasonvtg_candidates.sh \
  --output_jsonl output/reasonvtg_candidates_all.jsonl \
  --max_per_video 2 \
  --keep_existing_reasoning
```

### 3.2 GPU：SFT（EG-CoT）

```bash
bash train_scripts/run_sft_qwen3_8b.sh \
  --model_path "/path/to/Qwen3-VL-8B-Instruct" \
  --datasets egcot_jsonl \
  --data_path "output/TimeLens-8B/sft/egcot_timelens100k.jsonl" \
  --prompt_template egcot
```

### 3.3 GPU：GRPO（EAR + EG-CoT prompt）+ 自动合并 + Bench Eval

```bash
bash train_scripts/run_grpo_and_eval_qwen3_8b.sh \
  --model_path "<your_sft_ckpt_or_adapter>" \
  --raw_anno_path "<your_filtered_jsonl>" \
  --prompt_template egcot \
  --reward_funcs ear
```

### 3.4 tmux：一键启动

```bash
bash scripts/tmux_start_egcot_pipeline.sh \
  --base_model_path "/path/to/Qwen3-VL-8B-Instruct" \
  --filtered_jsonl "/path/to/gemini_refined_data.jsonl" \
  --run_data_prep true \
  --conda_env timelens

tmux attach -t <printed_session_name>
```

---

## 4. 我在机器上实际执行过的关键命令（摘要）

- 环境/硬件：`nvidia-smi -L`、`free -h`、`lscpu`、`df -h ...`
- 静态检查：`python -m py_compile ...`、`bash -n ...`
- 数据生成：
  - `bash scripts/prepare_egcot_data.sh ...`
  - `bash scripts/prepare_reasonvtg_candidates.sh ...`
- tmux：创建 session + 两窗跑数据（`timelens_prep`）

更完整日志见：`OPERATION_LOG_20260309.md`

---

## 5. 已知注意事项 / 明早常见坑

1) EG-CoT 的 60/40 分布会显著减少 perception 样本数
- 这是刻意的：原始 TimeLens-100K reasoning 很少，必须下采样 perception 才能做 60/40。

2) 外部 LLM 生成（openai/gemini）
- 需要你设置对应 env：`OPENAI_API_KEY` 或 `GEMINI_API_KEY/GOOGLE_API_KEY`。
- 推荐先用 `--llm_provider none` 跑通训练，再逐步替换为真实 EG-CoT。

3) Eval 模型路径
- 若你传 LoRA adapter（含 `adapter_config.json`），`evaluation/eval_dataloader.py` 支持 base+adapter 加载。
- 更推荐：训练脚本已经会自动 merge，再 eval 用 merged（避免“没合并导致 eval 无意义”）。

