# 操作日志（2026-03-09）

本日志用于记录本次为“LoRA 训练后自动合并权重再评测 + 脚本按硬件自适应参数”做的代码/脚本改动，以及我在机器上实际执行过的命令。

## 机器硬件快照
- GPU：`NVIDIA A100-SXM4-80GB` × 1（80GB）
- CPU：`Intel Xeon Platinum 8336C`（128 vCPU）
- 内存：约 `2.0 TiB`

## 我执行过的命令（按时间大致排序）
- 硬件信息：`nvidia-smi -L`、`nvidia-smi --query-gpu=...`、`free -h`、`lscpu`、`df -h ...`
- 脚本/代码冒烟检查：
  - `python -m py_compile scripts/merge_lora.py`
  - `bash -n train_scripts/run_grpo_qwen3_8b.sh`
  - `bash -n train_scripts/run_grpo_and_eval_qwen3_8b.sh`
  - `python scripts/merge_lora.py --help`

- EG-CoT / ReasonVTG / 分组评测相关（CPU）：
  - `python -m py_compile scripts/build_egcot_data.py training/train/reward_funcs.py training/data/grounding.py`
  - `python -m py_compile training/train/query_complexity.py evaluation/compute_metrics.py scripts/build_reasonvtg_bench.py`
  - `python scripts/build_reasonvtg_bench.py --bench_json ... --output_jsonl ...`

说明：当前环境的 `python` 为 3.13 且未安装 `torch/nncore`，因此无法在此会话里完成依赖齐全的 import 级冒烟测试；但脚本语法与 CLI 行为已做静态校验。

## 修改了哪些文件
- `scripts/merge_lora.py`
  - 改造成可复用 CLI：支持 `--lora_path/--out_path/--base_model_path/--skip_if_exists/--dry_run`。
  - 支持“训练前 base 是 adapter 时先合并”、“训练后 adapter 输出合并再 eval”。
- `train_scripts/run_grpo_qwen3_8b.sh`
  - 自动推断 `num_devices`：优先从 `CUDA_VISIBLE_DEVICES` 解析，其次用 `nvidia-smi -L`。
  - 按显存默认设置 `batch_per_device`：>=70GB 默认 `2`，否则 `1`（仍可用参数覆盖）。
  - 若 `--model_path` 指向 LoRA adapter（包含 `adapter_config.json`），训练前自动合并到 `${model_path}_merged`。
  - 增加一致性校验：`global_batch_size` 必须能被 `(batch_per_device*num_devices)` 整除。
- `train_scripts/run_grpo_and_eval_qwen3_8b.sh`
  - 同上：自动推断 `num_devices`、默认 `batch_per_device`、训练前自动合并 adapter base。
  - 训练结束后：若训练产物是 LoRA adapter（包含 `adapter_config.json`），自动合并到 `${trained_model_path}_merged`，并用 merged 结果跑 `scripts/eval_timelens_bench.sh`。
- `README.md`
  - 在 GRPO+Eval 的示例命令后补充说明：支持直接传 LoRA adapter 目录，脚本会自动合并并评测 merged。
- `param-line-edit-helper.SKILL.md`
  - 新增 LoRA 合并、GPU 数自适应、操作日志落盘的可复用 prompt 模板与行为模式。

## 新增：Evidence-Grounded Temporal Reasoning（EG-CoT / EAR / 数据准备）

### 新增/修改文件清单
- `scripts/build_egcot_data.py`
  - 从 TimeLens-100K 构建 EG-CoT SFT jsonl：规则分类 + 可选外部 LLM 生成 + 缓存 + 强制 <answer>=GT。
- `training/train/query_complexity.py`
  - QueryComplexityEstimator：rule_based（默认）+ 可选 surprisal（缺依赖时给出明确提示）。
- `training/data/grounding.py`
  - 新增 `PROMPT_EGCOT`，并通过 `--prompt_template egcot` 启用。
  - 支持 dataset `egcot_jsonl`（从 `--data_path` 读取 scripts/build_egcot_data.py 的输出）。
- `training/data/hybrid.py`
  - dataset 列表新增 `egcot_jsonl`。
- `training/params.py`
  - DataArguments 新增 `prompt_template`。
- `training/train/reward_funcs.py`
  - 新增 `ear`（Evidence-Aware Reward）并注册到 `REWARD_FUNCS_DICT`。
  - `format_reward` 放宽：允许仅 `<answer>...</answer>`（感知型跳过推理）。
- `evaluation/compute_metrics.py`
  - 新增 `--group_by_query_type`：按 query_type 分组统计 IOU0.3/0.5/0.7 和 mIoU。
- `scripts/build_reasonvtg_bench.py`
  - 基于 TimeLens-Bench 生成 ReasonVTG 候选（pair/triplet 组合生成，可验证，但默认需人工复核）。
- `scripts/prepare_egcot_data.sh`
  - 一键生成 EG-CoT SFT jsonl（CPU）。
- `scripts/prepare_reasonvtg_candidates.sh`
  - 一键生成 ReasonVTG 候选 jsonl（CPU）。

### CPU 侧数据准备：推荐命令

1）生成 EG-CoT SFT 训练数据（启发式版本，先跑通管线）：

```bash
bash scripts/prepare_egcot_data.sh \
  --input_jsonl data/TimeLens-100K/timelens-100k.jsonl \
  --output_jsonl output/TimeLens-8B/sft/egcot_timelens100k.jsonl \
  --target_reasoning_ratio 0.4
```

说明：`--target_reasoning_ratio` 通过“保留全部 reasoning + 下采样 perception”来逼近目标占比，生成的数据量会显著小于原始 100K（这是刻意的：保证 60/40 分布）。

2）生成 ReasonVTG 候选（待人工验证）：

```bash
bash scripts/prepare_reasonvtg_candidates.sh \
  --output_jsonl output/reasonvtg_candidates_all.jsonl \
  --max_per_video 2 \
  --keep_existing_reasoning
```

3）评测结果按 query_type 分组（对已有 pred jsonl）：

```bash
python evaluation/compute_metrics.py -f /path/to/preds.jsonl --group_by_query_type
```

## 明早一键跑（建议复制粘贴）

### A) 仅 CPU：准备数据（已在 tmux 跑过，可复跑）

```bash
source /home/tiger/miniconda3/etc/profile.d/conda.sh
conda activate timelens
cd /mnt/bn/aidp-data-multimodal-lf1/zhiwei/TimeLens

# EG-CoT SFT 数据
bash scripts/prepare_egcot_data.sh \
  --input_jsonl data/TimeLens-100K/timelens-100k.jsonl \
  --output_jsonl output/TimeLens-8B/sft/egcot_timelens100k.jsonl \
  --target_reasoning_ratio 0.4

# ReasonVTG 候选
bash scripts/prepare_reasonvtg_candidates.sh \
  --output_jsonl output/reasonvtg_candidates_all.jsonl \
  --max_per_video 2 \
  --keep_existing_reasoning
```

### B) GPU：SFT（EG-CoT）

```bash
source /home/tiger/miniconda3/etc/profile.d/conda.sh
conda activate timelens
cd /mnt/bn/aidp-data-multimodal-lf1/zhiwei/TimeLens

bash train_scripts/run_sft_qwen3_8b.sh \
  --model_path "/path/to/Qwen3-VL-8B-Instruct" \
  --datasets egcot_jsonl \
  --data_path "output/TimeLens-8B/sft/egcot_timelens100k.jsonl" \
  --prompt_template egcot
```

### C) GPU：GRPO（EAR + EG-CoT prompt）+ 自动合并 + Bench Eval

```bash
source /home/tiger/miniconda3/etc/profile.d/conda.sh
conda activate timelens
cd /mnt/bn/aidp-data-multimodal-lf1/zhiwei/TimeLens

bash train_scripts/run_grpo_and_eval_qwen3_8b.sh \
  --model_path "<your_sft_ckpt_or_adapter>" \
  --raw_anno_path "<your_filtered_jsonl>" \
  --prompt_template egcot \
  --reward_funcs ear
```

## tmux 一键启动（推荐给第二天早上）

脚本：`scripts/tmux_start_egcot_pipeline.sh`

示例：

```bash
bash scripts/tmux_start_egcot_pipeline.sh \
  --base_model_path "/path/to/Qwen3-VL-8B-Instruct" \
  --filtered_jsonl "/path/to/gemini_refined_data.jsonl" \
  --run_data_prep true \
  --conda_env timelens

# 进入 tmux
tmux attach -t <printed_session_name>
```

窗口说明：
- `egcot_data`：构建 EG-CoT SFT jsonl
- `reasonvtg`：构建 ReasonVTG 候选 jsonl
- `sft_egcot`：SFT（egcot_jsonl + egcot prompt）
- `grpo_ear`：GRPO+Eval（EAR + egcot prompt）

## 你现在应该如何一键运行（推荐）

### 1）GRPO 训练 + 自动合并 + Bench 评测（单卡/多卡通用）
单卡：

```bash
bash train_scripts/run_grpo_and_eval_qwen3_8b.sh \
  --model_path "/path/to/your_sft_checkpoint_or_lora_adapter" \
  --raw_anno_path "/path/to/gemini_refined_data.jsonl"
```

多卡（只需要设置 `CUDA_VISIBLE_DEVICES`；脚本会自动推断卡数并修正梯度累积）：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 bash train_scripts/run_grpo_and_eval_qwen3_8b.sh \
  --model_path "/path/to/your_sft_checkpoint_or_lora_adapter" \
  --raw_anno_path "/path/to/gemini_refined_data.jsonl"
```

输出：
- 训练输出目录：`output/TimeLens-8B/rlvr/<job_name>/grpo-*`
- 若为 LoRA adapter，会额外生成：`.../grpo-*_merged`，评测使用该 merged。

### 2）只做合并（可选）

```bash
python scripts/merge_lora.py \
  --lora_path "/path/to/lora_adapter" \
  --out_path "/path/to/merged" \
  --skip_if_exists
```
