---
name: evidence-grounded-tvg
description: 将 TimeLens 扩展为 Evidence-Grounded Temporal Reasoning（EG-CoT + EAR + CAT ref_steps），覆盖数据构建、prompt 开关、reward 注册、评测分组、tmux 一键启动与常见排错。
---

# 适用场景
- 你要在不改模型结构的前提下，让 VTG 同时兼容：
  - 感知型：直接 `<answer>`
  - 推理型：`<think>` 内带 `[Evidence@start-end_s]` 锚定
- 你要把“证据锚定”注入：SFT 数据 + GRPO reward，而不是模型结构。

# 关键组件（本仓库对应实现）
- EG-CoT 数据构建：`scripts/build_egcot_data.py`
  - 输入：TimeLens-100K 原始 jsonl（每行 video + events）
  - 输出：扁平化 jsonl（每条一个 event），含 `query_type/complexity_level/response`
  - 占比控制：保留全部 reasoning，下采样 perception 逼近 `--target_reasoning_ratio`
- Prompt 模板开关：`training/data/grounding.py`
  - `--prompt_template legacy|egcot`
  - `egcot` 模式支持两种输出格式（含/不含 `<think>`）
- 数据集接入：
  - `egcot_jsonl`：`training/data/grounding.py` 从 `--data_path` 读取构建后的 EG-CoT jsonl
- EAR 奖励：`training/train/reward_funcs.py`
  - reward 名称：`ear`
  - 从 completion 中解析 `<answer>` 与 `[Evidence@...]`
  - 计算：`R = R_answer × (1+αR_evidence) × γ_efficiency + δ·1(perception_no_think)`
- QueryComplexityEstimator：`training/train/query_complexity.py`
  - rule_based：训练/在线用（快）
  - surprisal：可选（数据构建用，依赖 torch/transformers）
- 评测按类型分组：`evaluation/compute_metrics.py --group_by_query_type`
- tmux 一键启动：`scripts/tmux_start_egcot_pipeline.sh`

# 一键命令模板（可复制）
## A) CPU：准备数据
```bash
bash scripts/prepare_egcot_data.sh \
  --input_jsonl data/TimeLens-100K/timelens-100k.jsonl \
  --output_jsonl output/TimeLens-8B/sft/egcot_timelens100k.jsonl \
  --target_reasoning_ratio 0.4

bash scripts/prepare_reasonvtg_candidates.sh \
  --output_jsonl output/reasonvtg_candidates_all.jsonl \
  --max_per_video 2 \
  --keep_existing_reasoning
```

## B) GPU：SFT（EG-CoT）
```bash
bash train_scripts/run_sft_qwen3_8b.sh \
  --model_path "/path/to/Qwen3-VL-8B-Instruct" \
  --datasets egcot_jsonl \
  --data_path "output/TimeLens-8B/sft/egcot_timelens100k.jsonl" \
  --prompt_template egcot
```

## C) GPU：GRPO（EAR + EG-CoT prompt）+ 自动合并 + Bench Eval
```bash
bash train_scripts/run_grpo_and_eval_qwen3_8b.sh \
  --model_path "<your_sft_ckpt_or_adapter>" \
  --raw_anno_path "<your_filtered_jsonl>" \
  --prompt_template egcot \
  --reward_funcs ear
```

## D) 评测：按类型分组
```bash
python evaluation/compute_metrics.py -f /path/to/preds.jsonl --group_by_query_type
```

# 常见坑与快速排错
1) EG-CoT 数据占比不对：
   - 原因：原始 TimeLens-100K 本身 reasoning query 很少。
   - 解法：脚本采用“保留全部 reasoning + 下采样 perception”，用 `--target_reasoning_ratio` 控制。
2) Eval 加载模型报错：
   - `dtype` vs `torch_dtype`：Transformers 用 `torch_dtype`。
   - Qwen3 需要 `trust_remote_code=True`。
   - adapter eval：如果目录里有 `adapter_config.json`，需要 base+adapter 加载（或先 merge）。
3) GRPO reward 接口不匹配：
   - reward 函数签名需兼容：`(prompts, completions, completion_ids, anno, prompt_text, **kwargs)`。
4) 输出格式约束：
   - perception 允许只输出 `<answer>`；format_reward 已放宽。

# 回顾提纲（明早快速复盘用）
- 我们实现了：EG-CoT 数据构建 + prompt 开关 + EAR reward + query_type 分组评测 + ReasonVTG 候选生成 + tmux 一键启动。
- 明早需要你补的变量只有两个：
  - `--base_model_path`（SFT base）
  - `--filtered_jsonl`（GRPO 输入）

