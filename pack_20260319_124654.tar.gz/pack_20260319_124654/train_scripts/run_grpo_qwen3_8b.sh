#!/usr/bin/env bash

set -euo pipefail

export PYTHONPATH="./:${PYTHONPATH:-}"
export CUDA_LAUNCH_BLOCKING=1

model_path=""
raw_anno_path=""
datasets="filtered_hybrid"
prompt_template="legacy"
model_id="qwen3-vl-8b"
min_tokens=64
total_tokens=14336
fps=1
fps_max_frames=""
seed=42

global_batch_size=16
batch_per_device=""
num_devices=""
epochs=1
target_size=2500
deepspeed_config="scripts/zero1.json"
output_root="output/TimeLens-8B/grpo"
report_to="none"
reward_funcs="tiou"

detect_num_devices() {
  if [[ -n "${CUDA_VISIBLE_DEVICES:-}" ]]; then
    IFS=',' read -ra _gpus <<< "${CUDA_VISIBLE_DEVICES}"
    echo "${#_gpus[@]}"
    return
  fi
  if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi -L 2>/dev/null | wc -l | tr -d ' '
    return
  fi
  echo 1
}

detect_gpu_mem_mib() {
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    echo 0
    return
  fi
  nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null \
    | head -n 1 \
    | tr -d ' '
}

ensure_merged_if_lora_adapter() {
  local maybe_adapter_path="$1"
  if [[ -f "${maybe_adapter_path%/}/adapter_config.json" ]]; then
    local merged_path="${maybe_adapter_path%/}_merged"
    echo "[run_grpo] Detected LoRA adapter model_path, merging first..."
    python scripts/merge_lora.py \
      --lora_path "${maybe_adapter_path%/}" \
      --out_path "${merged_path}" \
      --skip_if_exists
    echo "[run_grpo] Using merged base model: ${merged_path}"
    echo "${merged_path}"
  else
    echo "${maybe_adapter_path}"
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --model_path) model_path="$2"; shift 2 ;;
    --raw_anno_path) raw_anno_path="$2"; shift 2 ;;
    --datasets) datasets="$2"; shift 2 ;;
    --prompt_template) prompt_template="$2"; shift 2 ;;
    --min_tokens) min_tokens="$2"; shift 2 ;;
    --total_tokens) total_tokens="$2"; shift 2 ;;
    --fps) fps="$2"; shift 2 ;;
    --fps_max_frames) fps_max_frames="$2"; shift 2 ;;
    --seed) seed="$2"; shift 2 ;;
    --global_batch_size) global_batch_size="$2"; shift 2 ;;
    --batch_per_device) batch_per_device="$2"; shift 2 ;;
    --num_devices) num_devices="$2"; shift 2 ;;
    --epochs) epochs="$2"; shift 2 ;;
    --target_size) target_size="$2"; shift 2 ;;
    --deepspeed_config) deepspeed_config="$2"; shift 2 ;;
    --output_root) output_root="$2"; shift 2 ;;
    --report_to) report_to="$2"; shift 2 ;;
    --reward_funcs) reward_funcs="$2"; shift 2 ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

if [[ -z "${model_path}" ]]; then
  echo "--model_path is required (use the SFT checkpoint path)."
  exit 1
fi

if [[ -z "${raw_anno_path}" ]]; then
  echo "--raw_anno_path is required (use filtering output jsonl path)."
  exit 1
fi

model_path="$(ensure_merged_if_lora_adapter "${model_path}")"

if [[ -z "${num_devices}" ]]; then
  num_devices="$(detect_num_devices)"
fi

if [[ -z "${batch_per_device}" ]]; then
  # A100-80G (and similar) can usually fit batch=2 for this setup.
  gpu_mem_mib="$(detect_gpu_mem_mib)"
  if [[ "${gpu_mem_mib}" -ge 70000 ]]; then
    batch_per_device=2
  else
    batch_per_device=1
  fi
fi

if [[ "${num_devices}" -le 0 ]]; then
  echo "Invalid num_devices: ${num_devices}"
  exit 1
fi

if [[ $((batch_per_device * num_devices)) -le 0 ]]; then
  echo "Invalid batch_per_device*num_devices: ${batch_per_device} * ${num_devices}"
  exit 1
fi

if [[ $((global_batch_size % (batch_per_device * num_devices))) -ne 0 ]]; then
  echo "global_batch_size must be divisible by (batch_per_device*num_devices)."
  echo "Got global_batch_size=${global_batch_size}, batch_per_device=${batch_per_device}, num_devices=${num_devices}"
  exit 1
fi

grad_accum_steps=$((global_batch_size / (batch_per_device * num_devices)))
if [[ -z "${fps_max_frames}" ]]; then
  fps_max_frames=$((total_tokens / min_tokens * 2))
fi
run_tag="$(date +%Y%m%d-%H%M)"
run_name="grpo-${run_tag}_MAXFRAMES-${fps_max_frames}_FPS-${fps}_TOTALtokens-${total_tokens}_MINtokens-${min_tokens}"
output_dir="${output_root}/${run_name}"

mkdir -p "${output_dir}"
echo "Output directory: ${output_dir}"

deepspeed training/train/train_grpo_timelens.py \
  --bf16 True \
  --fp16 False \
  --disable_flash_attn2 False \
  --tf32 True \
  --gradient_checkpointing True \
  --lora_enable True \
  --lora_rank 64 \
  --lora_alpha 16 \
  --lora_dropout 0.05 \
  --deepspeed "${deepspeed_config}" \
  --model_name_or_path "${model_path}" \
  --model_id "${model_id}" \
  --datasets "${datasets}" \
  --raw_anno_path "${raw_anno_path}" \
  --prompt_template "${prompt_template}" \
  --fixed_gaussian_sampling True \
  --gaussian_filter_mean 0.05 \
  --gaussian_filter_std 0.2 \
  --target_size "${target_size}" \
  --remove_unused_columns False \
  --output_dir "${output_dir}" \
  --min_tokens "${min_tokens}" \
  --total_tokens "${total_tokens}" \
  --fps "${fps}" \
  --fps_max_frames "${fps_max_frames}" \
  --min_video_len 5 \
  --max_video_len 500 \
  --max_num_words 200 \
  --freeze_vision_tower True \
  --freeze_llm True \
  --freeze_merger False \
  --lr_scheduler_type constant \
  --learning_rate 1e-6 \
  --num_train_epochs "${epochs}" \
  --per_device_train_batch_size "${batch_per_device}" \
  --gradient_accumulation_steps "${grad_accum_steps}" \
  --logging_steps 1 \
  --save_strategy steps \
  --save_steps 100 \
  --save_total_limit 5 \
  --dataloader_num_workers 4 \
  --log_completions True \
  --use_liger False \
  --use_liger_loss False \
  --reward_funcs "${reward_funcs}" \
  --num_generations 4 \
  --steps_per_generation 4 \
  --temperature 1.0 \
  --scale_rewards False \
  --seed "${seed}" \
  --report_to "${report_to}" \
  --run_name "${model_id}-grpo/${run_name}" \
  --logging_dir wandb \
  --save_only_model True \
  --max_steps 100
